using Sirenix.OdinInspector;
using UnityEngine;

public class DialogInstigator : MonoBehaviour
{
    public DialogChannel dialogChannel;
    public FlowChannel flowChannel;
    public FlowState dialogState;

    public DialogSequencer dialogSequencer;
    public FlowState cachedFlowState;

    private void Awake()
    {
        dialogSequencer = new DialogSequencer();

        dialogSequencer.OnDialogStart += OnDialogStart;
        dialogSequencer.OnDialogEnd += OnDialogEnd;
        dialogSequencer.OnDialogNodeStart += dialogChannel.RaiseDialogNodeStart;
        dialogSequencer.OnDialogNodeEnd += dialogChannel.RaiseDialogNodeEnd;

        dialogChannel.OnDialogRequested += dialogSequencer.StartDialog;
        dialogChannel.OnDialogNodeRequested += dialogSequencer.StartDialogNode;
    }

    private void OnDestroy()
    {
        dialogChannel.OnDialogNodeRequested -= dialogSequencer.StartDialogNode;
        dialogChannel.OnDialogRequested -= dialogSequencer.StartDialog;

        dialogSequencer.OnDialogNodeEnd -= dialogChannel.RaiseDialogNodeEnd;
        dialogSequencer.OnDialogNodeStart -= dialogChannel.RaiseDialogNodeStart;
        dialogSequencer.OnDialogEnd -= OnDialogEnd;
        dialogSequencer.OnDialogStart -= OnDialogStart;

        dialogSequencer = null;
    }

    [Button]
    private void OnDialogStart(Dialog Dialog)
    {
        dialogChannel.RaiseDialogStart(Dialog);

        //cachedFlowState = FlowStateMachine.Instance.CurrentState;
        //flowChannel.RaiseFlowStateRequest(dialogState);
    }

    private void OnDialogEnd(Dialog Dialog)
    {
        flowChannel.RaiseFlowStateRequest(cachedFlowState);
        cachedFlowState = null;

        dialogChannel.RaiseDialogEnd(Dialog);
    }
}