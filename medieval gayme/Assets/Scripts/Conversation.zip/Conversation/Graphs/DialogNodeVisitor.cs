using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface DialogNodeVisitor
{
    void Visit(BasicDialogNode node);
    void Visit(ResponseDialogNode node);
}
