using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DialogNode : ScriptableObject
{
    public DialogLine dialogLine;

    public abstract bool CanBeFollowedByNode(DialogNode node);
    public abstract void Accept(DialogNodeVisitor visitor);
}
