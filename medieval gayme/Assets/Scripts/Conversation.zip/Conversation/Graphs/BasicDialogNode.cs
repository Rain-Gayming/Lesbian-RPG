using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(menuName = "NPC/Dialog/Basic Dialog Node")]
public class BasicDialogNode : DialogNode
{
    public DialogNode nextNode;


    public override bool CanBeFollowedByNode(DialogNode node)
    {
        return nextNode == node;
    }

    public override void Accept(DialogNodeVisitor visitor)
    {
        visitor.Visit(this);
    }
}
