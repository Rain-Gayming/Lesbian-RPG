using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[System.Serializable]
public class DialogueChoice
{

    public string choicePreview;
    public DialogNode choiceNode ;
}

[CreateAssetMenu(menuName = "NPC/Dialog/Dialog Response")]
public class ResponseDialogNode : DialogNode
{
    public DialogueChoice[] choices;


    public override bool CanBeFollowedByNode(DialogNode node)
    {
        return choices.Any(x => x.choiceNode == node);
    }

    public override void Accept(DialogNodeVisitor visitor)
    {
        visitor.Visit(this);
    }
}
