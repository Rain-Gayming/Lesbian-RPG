using UnityEngine;

[CreateAssetMenu(menuName = "NPC/Dialog/Dialog Channel")]
public class DialogChannel : ScriptableObject
{
    public delegate void DialogCallback(Dialog Dialog);
    public DialogCallback OnDialogRequested;
    public DialogCallback OnDialogStart;
    public DialogCallback OnDialogEnd;

    public delegate void DialogNodeCallback(DialogNode node);
    public DialogNodeCallback OnDialogNodeRequested;
    public DialogNodeCallback OnDialogNodeStart;
    public DialogNodeCallback OnDialogNodeEnd;

    public void RaiseRequestDialog(Dialog Dialog)
    {
        OnDialogRequested?.Invoke(Dialog);
    }

    public void RaiseDialogStart(Dialog Dialog)
    {
        OnDialogStart?.Invoke(Dialog);
    }

    public void RaiseDialogEnd(Dialog Dialog)
    {
        OnDialogEnd?.Invoke(Dialog);
    }

    public void RaiseRequestDialogNode(DialogNode node)
    {
        OnDialogNodeRequested?.Invoke(node);
    }

    public void RaiseDialogNodeStart(DialogNode node)
    {
        OnDialogNodeStart?.Invoke(node);
    }

    public void RaiseDialogNodeEnd(DialogNode node)
    {
        OnDialogNodeEnd?.Invoke(node);
    }
}