using TMPro;
using UnityEngine;
using UnityEngine.UI;
using Sirenix.OdinInspector;

public class DialogBoxUI : MonoBehaviour, DialogNodeVisitor
{
    public static DialogBoxUI instance;
    [BoxGroup("References")]
    public Menu dialogMenu;
    [BoxGroup("References")]
    public DialogChoiceController choiceControllerPrefab;
    [BoxGroup("References")]
    public DialogChannel dialogueChannel;

    [BoxGroup("UI")]
    public TextMeshProUGUI speakerText;
    [BoxGroup("UI")]
    public TextMeshProUGUI dialogueText;

    [BoxGroup("UI")]
    public RectTransform choicesBoxTransform;

    public bool m_ListenToInput = false;
    public DialogNode m_NextNode = null;

    public void Awake()
    {
        instance = this;
        dialogueChannel.OnDialogNodeStart += OnDialogueNodeStart;
        dialogueChannel.OnDialogNodeEnd += OnDialogueNodeEnd;
        choicesBoxTransform.gameObject.SetActive(false);
    }

    public void OnDestroy()
    {
        dialogueChannel.OnDialogNodeEnd -= OnDialogueNodeEnd;
        dialogueChannel.OnDialogNodeStart -= OnDialogueNodeStart;
    }

    public void Update()
    {
        if (m_ListenToInput && Input.GetButtonDown("Submit"))
        {
            dialogueChannel.RaiseRequestDialogNode(m_NextNode);
        }
    }

    public void OnDialogueNodeStart(DialogNode node)
    {
        dialogueText.text = node.dialogLine.dialogText;
        speakerText.text = node.dialogLine.npc.npcName;

        node.Accept(this);
    }

    public void OnDialogueNodeEnd(DialogNode node)
    {
        m_NextNode = null;
        m_ListenToInput = false;
        dialogueText.text = "";
        speakerText.text = "";

        foreach (Transform child in choicesBoxTransform)
        {
            Destroy(child.gameObject);
        }
        choicesBoxTransform.gameObject.SetActive(false);
    }

    public void Visit(BasicDialogNode node)
    {
        m_ListenToInput = true;
        m_NextNode = node.nextNode;
    }

    public void Visit(ResponseDialogNode node)
    {
        choicesBoxTransform.gameObject.SetActive(true);

        foreach (DialogueChoice choice in node.choices)
        {
            DialogChoiceController newChoice = Instantiate(choiceControllerPrefab, choicesBoxTransform);
            newChoice.choice = choice;
        }
    }
}