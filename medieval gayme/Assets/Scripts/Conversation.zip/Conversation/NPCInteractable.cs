using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;
using UnityEngine.Assertions.Must;

public class NPCInteractable : Interactable
{
    [BoxGroup("NPC")]
    public NPCObject npcInformation;
    [BoxGroup("NPC")]
    public DialogInstigator instigator;

    public override void Interact()
    {
        instigator.dialogChannel.RaiseDialogStart(npcInformation.dialog);
        MenuManager.instance.ChangeMenuWithPause(DialogBoxUI.instance.dialogMenu);
    }
}
