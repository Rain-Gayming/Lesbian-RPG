using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Sirenix.OdinInspector;

[CreateAssetMenu(menuName = "NPC/Dialog/Line")]
public class DialogLine : ScriptableObject
{
    [BoxGroup("Dialog Info")]
    public NPCObject npc;
    [BoxGroup("Dialog Info")][TextArea]
    public string dialogText;
}
