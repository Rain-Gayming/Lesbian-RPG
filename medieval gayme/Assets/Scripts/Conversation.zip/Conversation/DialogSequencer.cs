
public class DialogException : System.Exception
{
    public DialogException(string message)
        : base(message)
    {
    }
}

public class DialogSequencer
{
    public delegate void DialogCallback(Dialog Dialog);
    public delegate void DialogNodeCallback(DialogNode node);

    public DialogCallback OnDialogStart;
    public DialogCallback OnDialogEnd;
    public DialogNodeCallback OnDialogNodeStart;
    public DialogNodeCallback OnDialogNodeEnd;

    private Dialog currentDialog;
    private DialogNode currentNode;

    public void StartDialog(Dialog Dialog)
    {
        if (currentDialog == null)
        {
            currentDialog = Dialog;
            OnDialogStart?.Invoke(currentDialog);
            StartDialogNode(Dialog.firstNode);
        }
        else
        {
            throw new DialogException("Can't start a Dialog when another is already running.");
        }
    }

    public void EndDialog(Dialog Dialog)
    {
        if (currentDialog == Dialog)
        {
            StopDialogNode(currentNode);
            OnDialogEnd?.Invoke(currentDialog);
            currentDialog = null;
        }
        else
        {
            throw new DialogException("Trying to stop a Dialog that ins't running.");
        }
    }

    private bool CanStartNode(DialogNode node)
    {
        return (currentNode == null || node == null || currentNode.CanBeFollowedByNode(node));
    }

    public void StartDialogNode(DialogNode node)
    {
        if (CanStartNode(node))
        {
            StopDialogNode(currentNode);

            currentNode = node;

            if (currentNode != null)
            {
                OnDialogNodeStart?.Invoke(currentNode);
            }
            else
            {
                EndDialog(currentDialog);
            }
        }
        else
        {
            throw new DialogException("Failed to start Dialog node.");
        }
    }

    private void StopDialogNode(DialogNode node)
    {
        if (currentNode == node)
        {
            OnDialogNodeEnd?.Invoke(currentNode);
            currentNode = null;
        }
        else
        {
            throw new DialogException("Trying to stop a Dialog node that ins't running.");
        }
    }
}