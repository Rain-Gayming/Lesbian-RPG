using System.Security.Cryptography;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class DialogChoiceController : MonoBehaviour
{
    public TextMeshProUGUI choiceText;
    public DialogChannel dialogueChannel;
    public DialogNode choiceNextNode;

    public DialogueChoice choice
    {
        set
        {
            choiceText.text = value.choicePreview;
            choiceNextNode = value.choiceNode;
        }
    }

    private void Start()
    {
        GetComponent<Button>().onClick.AddListener(OnClick);
    }

    private void OnClick()
    {
        dialogueChannel.RaiseRequestDialogNode(choiceNextNode);
    }
}